export default from '@exodus/react-native-payments/lib/js/__mocks__';
