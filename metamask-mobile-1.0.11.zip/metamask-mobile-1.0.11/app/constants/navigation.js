export const PREVIOUS_SCREEN = 'previous_screen';
export const ONBOARDING = 'onboarding';
export const PROTECT = 'protect';
