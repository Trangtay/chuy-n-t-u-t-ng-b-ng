export const MAINNET = 'mainnet';
export const ROPSTEN = 'ropsten';
export const KOVAN = 'kovan';
export const RINKEBY = 'rinkeby';
export const GOERLI = 'goerli';
export const RPC = 'rpc';
