import StyledButton from './StyledButton'; // eslint-disable-line import/no-unresolved

export default StyledButton;
