// eslint-disable-next-line import/no-unresolved
import PaymentMethodSelector from './PaymentMethodSelector';

export default PaymentMethodSelector;
