import native from './native';
import usd from './usd';

const rules = {
	native,
	usd
};

export default rules;
