---
name: Usability enhancement
about: Suggest design improvements
title: ''
labels: ''
assignees: ''

---

**Describe the usability problem**
_A clear and concise description of the specific usability issue_

**Screenshots**
_If applicable, add screenshots or links to help explain the issue_

**Expected behavior**
_If possible, a clear and concise description / resolution of what you expected to happen_

------------------------------------------------------------------------------------------------------
_filled out after submission_

**User impact | Usage frequency | Feasibility scores**
_How important is this to the user, what the user wants to accomplish | Daily, weekly, monthly | Small, medium, large_
